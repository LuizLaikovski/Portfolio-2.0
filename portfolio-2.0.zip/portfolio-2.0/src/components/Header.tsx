const Header = () => {
    return (
        <header className="bvg-header p-4 bg-red-800 text-white">
            <h1 className="text-2xl font-bold">My Portfolio</h1>
        </header>
    );
};

export default Header;